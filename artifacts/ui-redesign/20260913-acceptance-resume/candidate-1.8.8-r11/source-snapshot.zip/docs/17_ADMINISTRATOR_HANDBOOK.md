# ETP Reporting Engine — Administrator Handbook

## Supported environment

- Windows 10/11 x64 with current security updates.
- SQL Server 2022 Express instance `SQLEXPRESS` and Windows authentication.
- Local administrator rights for installation and scheduled-backup registration.
- Source workbooks stored in an access-controlled business-data folder, never in the application repository.

## Installation and upgrade

1. Back up `EtpReporting` and verify the backup before any upgrade.
2. Run the versioned setup executable as administrator and keep the SQL bootstrap task selected. When `SQLEXPRESS` is missing, the bootstrap uses Windows Package Manager to install Microsoft's official SQL Server 2022 Express and Sqlcmd packages; internet access and acceptance of Microsoft's license terms are required.
3. The bootstrap preserves an existing `SQLEXPRESS` instance, configures automatic startup, applies only checksum-controlled application migrations, prepares backup access, and registers the daily backup, monthly recovery-drill and five-minute automated-operations tasks.
4. Launch the application, test the database connection, and confirm that the database reports no pending migration.
5. Retain the prior installer and verified database backup until acceptance is complete.

The bootstrap fails closed and records privacy-safe progress under `%ProgramData%\EtpReporting\SetupLogs`. It never uninstalls, replaces, downgrades, or deletes an existing SQL instance or database. A pending Windows restart or unavailable internet/package source can prevent a new SQL Server installation; restart or restore connectivity and rerun setup.

Uninstall from Windows **Installed apps**. Uninstall removes the three ETP scheduled tasks so they cannot point to missing program files. It does not delete SQL Server databases, source workbooks, exported reports, or administrator-created backups.

## Daily operation

- Check database availability, free disk space, backup age, and failed-import warnings before importing.
- Import only approved ETP workbooks or ZIP packages. Review the batch summary; retry only failed files after correcting the reported cause.
- Reconcile sales, tender, and stock controls. Tender differences are diagnostic findings and must not be silently adjusted.
- Export only to approved local folders. Treat every export as confidential business data.
- Confirm that the selected business date/store matches the ETP source scope. The importer records source report date, business date, importing Windows user and import timestamp separately.
- Finalisation is database-enforced. New source files and manual-input changes are rejected for a locked store/date. Reopen requires Windows administrator membership and a recorded reason.
- Treat R003/R013 as enrichment evidence only. Their order in a ZIP is irrelevant: R025 persistence rematches previously staged enrichment rows atomically without changing revenue totals.
- Service cash/card/UPI are controlled manual operational facts until a deterministic populated ETP Service profile is approved. They must never be merged into R025 retail sales.
- Use **Controlled restatement** only for a genuinely corrected export of the same report/store/business date. Reopen a locked date first, select the corrected workbook, and record a meaningful reason. The engine archives the replaced facts and applies the replacement atomically; it never silently overwrites them.
- Generate a complete reporting pack before finalisation. The generation number, SHA-256 control snapshot and predecessor link are immutable; the finalisation transaction marks the latest generation final.
- Review **Control Centre** for unattended runs, import conflicts, approvals, data-quality findings and scheduled-report status. Stable workbooks/ZIPs are imported; PDFs/images enter Source Inbox; duplicates move below Processed\Duplicate; failures move to quarantine.
- Use **Archive** to open, compare, package and share stored generations. The application verifies each archived document hash before use and records only share initiation unless delivery is verifiable.
- Configure the optional signed PaddleOCR helper/model paths under product settings only after verifying their hashes. Reporting must remain available when OCR is disabled or unhealthy.
- Approve accounting mappings only after the Tally ledger/tax treatment is confirmed. Back up the Tally company before importing the generated balanced XML and review its import exceptions.

## Approved access policy

- **Owner/Admin:** has all application and administrative rights, including imports, SQL Server connection administration, database maintenance, and approval of mapping or control-rule changes.
- **Store Manager:** may import approved ETP reports and use reports/exports, but may not approve or alter mappings, signs, tolerances, control rules, SQL connections, or database configuration.
- **Viewer:** may view dashboards, reports and the archive, but cannot import, enter operations or administer configuration.
- **Other users:** have no access unless an Owner explicitly creates and activates their Windows identity.
- Codex may assist the Owner with technical administration only during an Owner-authorized session. Codex is not an independent account, administrator, or approval authority.

Authentication is Windows-integrated: the signed-in `DOMAIN\User` or `COMPUTER\User` is matched to the audited application user register. The account that applies migration 0011 becomes the initial active Owner. Owners manage additional users under **Masters**. There is no application password to store, share or reset.

## Backup and recovery

Use the scripts described in [Operations and Recovery](16_OPERATIONS_AND_RECOVERY.md). Retain every database backup indefinitely and never delete business/import data. A successful job run is not sufficient: monitor backup age and run the isolated restore drill monthly. Never restore over production during a drill. Operational audit history is retained for two years.

Recovery sequence:

1. Stop imports and record the incident time.
2. Select the latest checksum-verified backup that predates the incident.
3. Restore into a temporary validation database and run integrity/lineage checks.
4. Obtain business approval before replacing or redirecting production.
5. Record backup identity, restore result, row/control comparisons, operator, and time.

## Diagnostics and support

Create the offline support package from **Operations Center** or the approved support script. It contains aggregate health, service and scheduled-task status only—never workbook rows, invoice identifiers, customer details, tender references, connection passwords, database backups or source filenames.

Run `scripts/invoke-security-scan.ps1` before each release. Address dependency findings or document a time-bound exception. Use `scripts/test-windows-ui.ps1 -AccessibilityAudit` and the installer lifecycle test for release acceptance.

## Release process

1. Update `CHANGELOG.md` and run `scripts/set-release-version.ps1`.
2. Run automated tests and dependency scans.
3. Build the portable release with `scripts/build-windows-release.ps1`.
4. Build the installer with `scripts/build-installer.ps1`.
5. Run Windows UI and isolated install/upgrade/uninstall tests.
6. Record SHA-256 checksums and acceptance evidence; refresh Graphify; commit only reviewed source and documentation.

## Remaining Owner decisions

The application deliberately does not invent the meaning of TC or unapproved tender types; exchange/cancel/credit-note/zero-value transaction treatment; DSR versus staff transaction denominators; physical-stock composition; stock movement signs; or customer-identifying output. Approve these in writing before changing the controlled registry or profiles. A populated ETP Service report also needs an approved sample/profile before replacing controlled manual service entry.
