# r10/r11 density placement and acceptance VM upgrade

**INCOMPLETE — WORK REMAINS.** This checkpoint implements the user's density placement request. It does not claim repair of the separately reported Settings sidebar, Start menu visibility or missing window controls.

## Fresh VM baseline and preservation

The elevated worker connected to ETP-Acceptance-186 as its existing ETPTest account. Installed baseline is 1.8.7 (`B5C74F5415EF1C6DE91C58424ABF131E3DBAD1399567DA152C300FAE8001264B`), not the host's 1.8.5 or the archived r9 candidate. Original counts are 3 sales rows, 2300 net, 2 units, 1 imported file and 3 lineage rows. Original application payload and local settings were copied to `C:\ETPAcceptance\UI-20260913-baseline` inside the VM.

Original COPY_ONLY/CHECKSUM backup passed RESTORE VERIFYONLY WITH CHECKSUM. Its hash is `9D8D069D3D08D14215C8CFAFD720F59E8442C0727C4B7AEA0CAFAE8A52CA3A3F`; path is recorded in the [protected baseline receipt](../../artifacts/ui-redesign/20260913-acceptance-resume/vm-protected-baseline.json). This is backup verification, not an isolated full restore test. Original source tables were not changed by the baseline/backup job. An evidence-copy step initially failed because zero running ETP processes produced no JSON file; the follow-up wrote an explicit empty array and completed evidence copying. Both attempts are retained.

The baseline found the all-users Start menu ETP shortcut and Desktop shortcut, each pointing to the installed executable. File presence is not proof of visible Start menu discovery or launch.

## Implemented change and regression

- Removed the density selector from the global footer. Settings → Display → Display & Preferences now shows the selected Compact/Comfortable option and saves the preference through the existing local store.
- Personal preferences remain reachable by Viewer, Store Manager and Owner. Database Connection, Users & Roles and Recovery retain administration guards. Administrative Help now opens Users & Roles instead of personal display preferences.
- F6 cycles search, scope and focused task content. Status details remains docked correctly after removal of the old footer control. Opening personal display preferences does not start a database-bound work session.
- Final Release validation passed **669 tests**: 345 Desktop, 195 SQL, 66 Reporting, 51 Import and 12 Domain. Earlier failed attempts are preserved: obsolete named-control count, a test using the wrong navigation property name, and the administrative Help link caught by the existing role test. These were repaired before packaging.

Source starts at `d24a525`; runtime changes remain in the working tree and are identified by the new immutable candidate source archive/manifest, not HEAD alone. No financial, SQL, import or report calculation implementation changed.

## Installation checkpoint

r10 installed successfully at 09:06:38 UTC. The installed executable SHA256 is `F556E125EFB61C9A48451BB8D1310983902835F435E062EC715EAB7A8F5B90E7`; installer SHA256 is `9F3B85F2D3224D6A530BCADC90974682578C1C31A96CFB3D9EDBFFABEE91C926`. Installer exit code was 0; original sales/import/lineage counts and settings hashes were unchanged; DBCC CHECKDB passed. The all-users Start menu shortcut targets the hash-verified installed executable. [Installed result](../../artifacts/ui-redesign/20260913-acceptance-resume/vm-r10-install-result.json). This is an installed file/data check, not a UI launch or journey pass.

Final source review found the reused density selector's accessibility help text was set only during initialization and could describe the previous density after a selection. r11 updates that description when the selected radio button changes. The r10 source snapshot preserves the before implementation; no visual before/after evidence is available. r10 and its evidence remain immutable. r11 packaging/installation is in progress; no r11 installed pass is claimed at this checkpoint.

## Remaining acceptance and exact next action

Native capture of the VM window failed twice with `SetIsBorderRequired … 0x80004002`, including refreshed window selection. Worker access is now available; screen control/capture is a separate unresolved limitation. No app clicks, keyboard actions, physical touch, screenshots or visible before/after results are claimed for this VM run.

After installing and verifying the candidate, obtain supported VM screen capture/input. Reproduce the original Settings sidebar symptom and the reported missing title-bar buttons on the actual installed build before attributing a cause. The source currently retains standard WPF window chrome; no source repair for missing caption buttons is justified by the available evidence. Observe Start menu discovery and shortcut launch. Test Display in both densities with saved selection, restart, all roles and keyboard focus. Then resume all J01–J18, every active destination, 29 reports and saved UI exports, dialogs, native scaling, Narrator, physical touch, performance and installer/recovery lifecycle. All complete journeys remain UNVERIFIED; no four-phase acceptance gate is upgraded.
