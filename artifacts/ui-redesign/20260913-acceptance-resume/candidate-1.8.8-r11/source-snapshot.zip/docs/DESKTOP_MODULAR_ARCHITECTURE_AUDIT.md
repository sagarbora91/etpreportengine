# Desktop Modular Architecture Audit

## Executive assessment

**Risk: MEDIUM.** The Desktop shell-only extraction is complete in source: `DesktopCompositionRoot` owns construction, every major destination has an owning module workspace, and `MainWindow` is limited to window chrome, navigation, global access/status/audit relays and compact workspace hosts. Remaining risk is behavioural acceptance of the extracted workflows against representative live SQL data and golden report/export artefacts, not a known shell-boundary violation.

The required response is an incremental behaviour-preserving extraction, not a rewrite. Import rules, report calculations, database structures and user-facing behaviour remain unchanged.

## Phase 0 baseline

Measured on 2026-08-27 before modular extraction:

| Measure | Baseline |
|---|---:|
| Branch | `ui/uiux-v4-touch-first-redesign` |
| Commit | `9abab67cf8eca8c7cf4c7252b431abc632ac6456` |
| .NET SDK | `10.0.400` |
| Solution build | Passed; 0 warnings, 0 errors |
| Tests | 188 passed; 0 failed; 0 skipped |
| Domain tests | 12 passed |
| Desktop tests | 41 passed |
| Reporting tests | 51 passed |
| Import tests | 40 passed |
| SQL Server tests | 44 passed |

The working tree already contained unrelated and knowledge/Graphify changes. They are part of the baseline work state and must not be attributed to the modular refactor.

The automated baseline does not prove that WPF launched against a live SQL Server, that a representative production workbook imported, or that generated Excel/PDF bytes match a golden master. Those checks are required before high-risk module extraction.

## Current project dependencies

```text
Domain                         → (none)
Application                    → (none)
Reporting                      → (none)
Import                         → Domain
Infrastructure.SqlServer       → Import, Domain, Reporting
Desktop                        → Import, Infrastructure.SqlServer, Reporting
```

The dependency list above is the Phase 0 baseline. Desktop now also consumes `Application`. SQL adapters remain referenced by the executable composition boundary, while `MainWindow` and the module presentation layer consume injected application/reporting abstractions and composed workspace views. Architecture tests prevent SQL infrastructure construction from returning to views or the shell.

## Phase 0 Desktop structure

```text
Etp.Reporting.Desktop/
├── App.xaml / App.xaml.cs
├── MainWindow.xaml
├── MainWindow.xaml.cs
├── MainWindow.Shell.cs
├── MainWindow.Workspaces.cs
├── MainWindow.VisualReporting.cs
├── MainWindow.Productisation.cs
├── ShellNavigation.cs
├── UiNavigation.cs
├── ReportWorkspaceControls.cs
├── DailySalesReportControls.cs
├── HelpCentre.cs / HelpCentreControls.cs
├── UiControls.cs / DensitySelector.cs
├── PowerShellOperationsService.cs
├── Themes/
└── Assets/
```

There are no established `Views/` or `ViewModels/` module folders and no shell view model. Useful extraction seams already exist in `WorkspaceNavigationHistory`, `ShellShortcutRegistry`, `UiNavigationRegistry`, report workspace controls, the DSR workspace and Help Centre.

## Phase 0 MainWindow measurements

| File | Physical lines | Declared methods | Event-handler-shaped methods |
|---|---:|---:|---:|
| `MainWindow.xaml.cs` | 1,446 | 95 | 56 |
| `MainWindow.Shell.cs` | 436 | 39 | 12 |
| `MainWindow.Productisation.cs` | 349 | 35 | 26 |
| `MainWindow.Workspaces.cs` | 263 | 14 | 0 |
| `MainWindow.VisualReporting.cs` | 90 | 5 | 0 |
| **Total** | **2,584** | **188** | **94** |

The partial class also holds 40 fields. Its public constructor takes no dependencies, yet its methods instantiate more than 20 concrete service/repository/export types. `MainWindow.xaml` has 236 physical lines, 223 named controls and 122 event bindings; compact XAML formatting makes physical line count particularly misleading.

## Phase 0 responsibility matrix

| Responsibility | Current owner/evidence | Correct owner | Priority | Risk |
|---|---|---|---|---|
| Window startup, chrome, global status and workspace host | `App`, `MainWindow`, `MainWindow.Shell` | Desktop shell | High | Low |
| Module registry, history, shortcuts, destination selection | `UiNavigation`, `ShellNavigation`, `MainWindow.Shell` | Framework-neutral Desktop navigation | Critical | Low |
| Panel visibility and active workspace state | `MainWindow.Navigate_Click`, shell/workspace partials | Shell view model/coordinator and workspace host | Critical | Medium |
| Access checks and current Windows role | `MainWindow` via `Phase2OperationsRepository` | Application access service; shell consumes presentation state | High | Medium |
| Daily workflow, manual inputs, counts, targets, finalise/reopen | `MainWindow.xaml.cs` | Daily-workflow view model plus application workflow | High | High |
| Workbook validation, staging, batch import, retry/cancel/restatement | `MainWindow.xaml.cs` | Import view model plus Import/Application contracts | Critical | High |
| Source inbox and extraction review | `MainWindow.Productisation.cs` | Source-inbox workspace plus application service | High | High |
| Report selection and execution | MainWindow handlers plus focused report controls | Report workspace view models plus reporting application service | Critical | High |
| Visual report rendering | `MainWindow.VisualReporting.cs` | Reusable Desktop report view/control | Medium | Medium |
| Excel, PDF and report-pack export orchestration | `MainWindow.xaml.cs` and workspace callbacks | Report application service; Desktop owns dialogs only | High | High |
| Dashboard and operational status | `MainWindow.xaml.cs` | Dashboard workspace/view model | High | Medium |
| Archive, comparison, packaging and sharing | MainWindow base/productisation partials | Archive workspace plus application service | High | Medium |
| Accounting preparation and Tally export | `MainWindow.Productisation.cs` | Accounting workspace plus application service | High | High |
| Automation, backup, recovery and support packages | `MainWindow.xaml.cs`, `PowerShellOperationsService` | Operations workspace and explicit operational contracts | High | High |
| Masters, users, approvals, registers and product settings | MainWindow base/productisation partials | Focused administration workspaces | Medium | Medium |
| File and message dialogs | MainWindow handlers | Desktop dialog services where reuse/testing warrants it | Medium | Low |
| Connection-string and UI preference persistence | MainWindow and `UiPreferenceStore` | Settings service and module/shell state | Medium | Medium |

No raw SQL statements or `SqlCommand` use were found in Desktop. The violation is direct construction and invocation of SQL infrastructure repositories from UI code, often using a connection string stored in a text control.

## Critical workflows to preserve

- normal startup, database-initialization startup and one-shot automation startup;
- Windows identity/role loading, authorization and database health;
- connection testing, database bootstrap and settings persistence;
- file/folder/ZIP selection, preflight, validation, staging, persistence, restatement, retry and cancellation;
- source-document intake, integrity verification and extraction review;
- daily inputs, stock counts, staff targets, readiness, finalisation and reopening;
- catalogue reports, DSR, invoice, tender, stock, staff, service and exception reports;
- focused preview, visual summaries, Excel/PDF and report-pack export;
- dashboard, operational controls, backup/recovery and support packages;
- historical date ranges, immutable archive, comparison, re-export, ZIP and sharing;
- accounting preparation, approval and Tally XML export;
- masters, access administration, approvals and registers.

## Target Desktop structure

This target evolves the seams already present; it is not a requirement to create every folder immediately.

```text
Etp.Reporting.Desktop/
├── App.xaml / App.xaml.cs             # composition root and process-level failures
├── Shell/
│   ├── MainWindow.xaml / .cs          # window host only
│   └── ShellViewModel.cs               # global presentation state only
│   ├── Navigation/                     # route state; no WPF, Import, SQL or Reporting references
│   │   ├── NavigationService.cs
│   ├── WorkspaceLocation.cs
│   └── NavigationRegistry.cs
├── Modules/
│   ├── Help/
│   ├── Settings/
│   ├── Archive/
│   ├── Reports/
│   ├── Dashboard/
│   ├── DailyWorkflow/
│   ├── Imports/
│   ├── Accounting/
│   └── Administration/
│       # each module owns cohesive Views and ViewModels
├── Services/
│   ├── Dialogs/
│   ├── Notifications/
│   └── DesktopIntegration/
├── Controls/
├── Converters/
├── Themes/
└── Assets/
```

Use cases and database/report/import behaviour belong outside Desktop. A view model may coordinate a UI-facing action through an application contract, but it must not become a replacement God object or a repository layer.

## Incremental migration and risk

| Sequence | Extraction | Behavioural risk | Data/reporting risk | Rollback |
|---:|---|---|---|---|
| 1 | Navigation state and destination selection; reuse history/registry | Low | None | Restore shell calls to current methods |
| 2 | Shell global state, Help and module-home presentation | Low | None | Reconnect existing controls/code-behind |
| 3 | Settings and desktop dialog/persistence services | Medium | Connection configuration | Restore existing settings handlers |
| 4 | Archive, sharing and registers | Medium | Immutable-generation selection | Reconnect existing repository-backed handlers |
| 5 | Reports workspace orchestration and export | High | Financial output and export stability | Keep old handlers until golden comparison passes |
| 6 | Dashboard and daily workflow | High | Finalisation and controlled inputs | Retain old route behind a small reversible seam |
| 7 | Import and Source Inbox | High | Canonical facts, lineage and restatement | Extract one operation at a time; compare database effects |
| 8 | Accounting, operations, approvals and administration | High | Audit, backup and accounting controls | Separate commits per workspace and revert individually |
| 9 | Remove obsolete partial methods/fields and enforce boundaries | Medium | Indirect regression only | Delete only after references and smoke tests are clean |

After every step: build, run relevant tests, launch the application, exercise the affected workflow and compare representative outputs/effects with the baseline. Do not combine visual redesign, formula change, mapping change or schema change with structural extraction.

## Expected file changes

Likely creations include shell/navigation classes, module views/view models, Desktop service abstractions, application use-case contracts and architecture tests. Likely modifications include `App.xaml.cs` as composition root, `MainWindow` host wiring, Desktop project references and focused tests. Existing `MainWindow.*` partial files become removable only after their responsibilities have moved and source/Graphify references are clean. No planning phase should delete them.

## Guardrails

- **DESK-001:** `MainWindow` is the application shell and workspace host only.
- **DESK-002:** Views contain presentation and control interaction only.
- **DESK-003:** View models expose module presentation state and invoke application abstractions; they contain no report formulas or data access.
- **DESK-004:** Desktop does not execute SQL or construct SQL repositories inside views/view models.
- **DESK-005:** Reporting formulas and deterministic export models remain outside Desktop.
- **DESK-006:** Workbook parsing, profile recognition, staging and normalization remain outside Desktop.
- **DESK-007:** Every major workspace has an explicit owner and may be decomposed by cohesive sub-feature.
- **DESK-008:** New features are assigned to an owning module before code is added.
- **DESK-009:** Shell route/navigation state has no WPF, Import, SQL Server or Reporting assembly dependency. Route metadata and access policy may use stable feature identifiers without calling feature implementations.
- **DESK-010:** Domain, Application, Import, Reporting and SQL infrastructure never reference Desktop.
- **DESK-011:** One composition root constructs application dependencies; mutable global service location is prohibited.
- **DESK-012:** Every extraction preserves import/database/report behaviour and is independently reversible.

`DesktopArchitectureTests` enforces DESK-009 and DESK-010 without introducing an architecture-test framework. Graphify should be updated after structural phases and used to confirm that MainWindow responsibility and fan-out decrease.

## Implemented checkpoint — 2026-08-27

The first low-risk slice and one representative data-backed workspace are now implemented:

1. `ShellNavigationService` owns route selection, metadata, access decisions and back/forward history without WPF or feature-layer dependencies.
2. `HelpWorkspaceSession` owns Help Centre open/close and return-state behavior.
3. `DashboardView` owns Dashboard controls, accessibility labels, formatting and chart rendering.
4. `IDashboardQuery` defines the Application-layer read contract; `SqlServerDashboardQuery` adapts the existing SQL repositories without changing their queries or mappings.
5. Focused navigation, Help, Dashboard presentation, Dashboard contract, SQL adapter and architecture tests protect these boundaries.

Measured after the slice, the five `MainWindow` C# partials reduced from 2,584 to 2,521 physical lines and `MainWindow.xaml` reduced from 236 to 222 lines. The application remains a single WPF executable. The implementation intentionally preserves panel visibility, permissions, refresh, audit and PDF behavior; the automated suite, UI shell smoke run and representative DSR PDF comparison passed. Live connected-SQL workflow validation remains a separate operator acceptance step. Dashboard dependency construction also remains temporarily in `MainWindow`, so DESK-011 is not yet complete.

This checkpoint does not declare the wider modular migration complete. Reports, Daily Workflow, Import, Archive, Settings, Accounting, Operations and Administration remain in `MainWindow` and must continue as separate reversible slices. Report formulas, mappings, schemas and import behavior were deliberately not changed in this checkpoint.

## Architecture ratchet baseline — 2026-08-28

The Desktop test suite now treats direct construction of concrete SQL-infrastructure collaborators as a ratchet. Views and view models have a zero-tolerance boundary: they may not reference `Etp.Reporting.Infrastructure.SqlServer` or `Microsoft.Data.SqlClient`, and Desktop modules may not reference another module directly. The framework-neutral navigation folder also may not reference a Desktop module.

`MainWindow` still has 83 temporary direct constructions of SQL-infrastructure concrete classes: 56 in `MainWindow.xaml.cs` and 27 in `MainWindow.Productisation.cs`. The executable inventory is recorded by type and file in `DesktopCompositionGuardrailTests`. Existing counts may decrease during extraction, but a new type/file pair or an increase above any recorded maximum fails the suite. This is a containment checkpoint, not compliance with DESK-004 or DESK-011; those guardrails remain incomplete until the inventory reaches zero and composition is owned outside the shell.

## First composition slice — 2026-08-28

`DesktopCompositionRoot` now owns normal MainWindow construction, database-initialization startup, one-shot automation startup, the per-window `ShellViewModel`, `DashboardView` and the connection-aware Dashboard query factory. `MainWindow` receives these collaborators explicitly and no longer constructs `ShellNavigationService`, `DashboardView` or `SqlServerDashboardQuery`. The Shell ViewModel owns route/history/access decisions and descriptor-derived presentation metadata without WPF or feature-layer state.

This reduces the ratcheted MainWindow SQL-infrastructure construction inventory from 83 to 82. It does not complete DESK-011: the remaining feature workflows still construct their concrete collaborators in MainWindow and must migrate through the subsequent workspace slices. Release build, 254 automated tests and the 11-view headless WPF smoke passed for this slice. A framework-neutral startup coordinator also verifies exact argument routing, headless no-window behavior, exit codes and diagnostic labels without mutating SQL state.

## Settings, connection-state and access slice — 28 August 2026

`DesktopCompositionRoot` now constructs an absolute-rooted atomic Desktop settings store, validated connection state and the SQL implementation of the Application access-session contract. `MainWindow` no longer loads or writes settings files and no feature service reads `ConnectionStringInput.Text`; the textbox is limited to accepting and presenting a candidate connection. Desktop role-aware navigation now consumes the Application access role and permission matrix.

This slice reduces the ratcheted MainWindow SQL-infrastructure construction inventory from 82 to 81 by removing current-access repository construction from the shell. The Settings view and other feature workflows remain in `MainWindow`; therefore DESK-001, DESK-004 and DESK-011 remain open. Release build, 289 automated tests and the 11-view/190-name WPF smoke pass.

## Archive, registers and shortcut-parity slice — 28 August 2026

Archive search/open/comparison, Sharing Contacts and Digital Registers now depend on Application contracts whose SQL adapters are constructed by `DesktopCompositionRoot`. The archive adapter preserves the existing integrity-checked document load; the contact and register adapters preserve Owner enforcement, locked-day controls and database audit behavior. This reduces MainWindow SQL-infrastructure construction from 81 to 74.

The Help catalogue now derives executable gesture labels from `ShellShortcutRegistry`, bidirectional tests prevent unsupported executable claims, and `Ctrl+R` is guarded to the enabled retry action in Imports. Release build, 316 automated tests and the 11-view/190-name WPF smoke pass. Archive/register/contact controls still live in MainWindow, so DESK-001 and the overall modular migration remain open.

## Daily Workflow and Manual Entry application slice — 28 August 2026

Daily readiness/manual-input queries, controlled writes/finalisation and report-pack generation now cross three cohesive Application ports implemented by `SqlServerDailyWorkflowService`. The adapter delegates to the existing workflow, completion and pack implementations, preserving missing-versus-zero state, stock composition, staff targets, blocker evaluation, locked-day enforcement, administrator-approved reopening, and immutable generation hashes.

This reduces MainWindow SQL-infrastructure construction from 74 to 64. Release build, 335 automated tests and the 11-view/190-name WPF smoke pass. The Daily Workflow controls remain embedded in MainWindow pending presentation extraction, so the shell-only gate is still open.

## Source Inbox boundary and prepared report/accounting ports — 28 August 2026

Source Inbox document/extraction reads, human review, document intake and managed-file integrity verification now cross `ISourceInboxService`, implemented by a SQL adapter composed outside the shell. This reduces MainWindow SQL-infrastructure construction from 64 to 60 while retaining immutable document, SHA-256, duplicate, quarantine and audit behavior.

Dependency-free Reports and Accounting contracts plus tested SQL facades are also present, but their MainWindow call sites are not yet migrated and therefore do not reduce the ratchet in this checkpoint. Release build, 363 automated tests and the 11-view/190-name WPF smoke pass.

## Final shell-only checkpoint — 28 August 2026

This checkpoint supersedes the implementation-status statements in the historical slices above. All shell destinations are now compact hosts for composed module views: Dashboard, Settings, Daily Workflow, Import, Source Inbox, Reports, Operations, Investigation/Approvals, Archive/Sharing, Registers, Accounting and Administration. `WorkspaceModuleOwnershipRegistry` maps every `ShellRouteRegistry` destination and report route to an owning module, with bidirectional tests preventing unowned routes.

`MainWindow.Productisation.cs` and `MainWindow.VisualReporting.cs` have been removed. Report scope, queries, projections, formulas, filtering, detail presentation and Excel/PDF actions are owned by `ReportsWorkspaceView`; Dashboard and Daily Workflow export presentation is also owned by those module views. Import parsing/orchestration, archive/sharing, registers, accounting, source inbox, settings and operations/administration handlers are likewise outside `MainWindow`. `DesktopFriendlyError` owns provider-specific error classification, leaving no SQL-provider or Infrastructure reference in the shell partials. `DesktopCompositionRoot` constructs the Daily Workflow and Reports views and all infrastructure adapters.

Final source ratchets:

| Measure | Phase 0 | Final shell |
|---|---:|---:|
| `MainWindow` C# partials | 5 | 3 |
| `MainWindow` C# physical lines | 2,584 | 907 |
| `MainWindow` declared methods | 188 | 62 |
| `MainWindow` fields | 40 | 29 |
| `MainWindow.xaml` physical lines | 236 | 93 |
| `MainWindow.xaml` named controls | 223 | 58 |
| `MainWindow.xaml` event bindings | 122 | 13 |
| Direct SQL-infrastructure construction in `MainWindow` | 83 at first executable inventory | 0 |

`MainWindowShellBoundaryTests` prevents feature partials, infrastructure construction, workbook parsing, report formula/export orchestration and feature control names or handlers from regrowing in the shell. Existing composition and module-boundary tests additionally enforce no SQL references in views/view models and no direct cross-module references.

Verification for this checkpoint: the Release Desktop build passed with 0 warnings and 0 errors; the focused architecture, composition, Reports, navigation and WPF UI-smoke set passed 114/114; and the formerly stale Archive, Settings, Operations/Administration, Registers/Accounting and extracted-workspace UI checks passed 26/26. These sets overlap and are reported separately rather than summed.

The structural Desktop objective is complete. Operator acceptance remains required for a live connected-SQL launch, representative import/restatement/cancellation paths, role-specific actions, and byte/semantic comparison of representative Excel, PDF, report-pack and Tally outputs. Those are runtime/data acceptance gates, not reasons to return feature ownership to the shell.
